let serverURL;
let usernameInput;
let projectIDs;
serverURL = " https://9ca2-67-218-23-206.ngrok.io"
//serverURL = "https://scholawrite.ngrok.app/"

chrome.storage.local.get(["projectIDs"], async function(result){
    projectIDs = result.projectIDs;
    console.log(projectIDs);
});

function clearError(){
    var errMessage = document.querySelectorAll('p[style="color: red; font-size: 14px;"]');
    console.log("here")
    if (errMessage !== null){
        errMessage.forEach((node) => {
            node.parentNode.removeChild(node);
        });
    }
    var notiMessage = document.querySelectorAll('p[style="color: black; font-size: 14px;"]');
    if (notiMessage !== null){
        notiMessage.forEach((node) => {
            node.parentNode.removeChild(node);
        });
    }

    var dividers = document.querySelectorAll('.divider');
    if (dividers !== null){
        dividers.forEach((node) => {
            node.style.margin = "20px 0";
        });
    }
};

function showError(pos, node, text){
    var textElement = document.createElement("p");
    textElement.innerText = text;
    textElement.style.color = "red";
    textElement.style.fontSize = "14px";
    if (pos === 1){
        node.parentNode.insertBefore(textElement, node);
    }
    else if (pos === 2){
        node.parentNode.insertBefore(textElement, node.nextElementSibling);
    }
}

function addTextBox(innerID) {
    const target = document.getElementById("add");
    const textboxContainer = document.createElement('div');
    const scrollContainer = document.getElementsByClassName('scroll-container')[0];
    textboxContainer.className = 'textbox-container';

    const textBox = document.createElement('input');
    textBox.type = 'text';
    textBox.className = 'textbox';
    textBox.value = innerID;

    const deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.className = 'del';
    deleteButton.onclick = function() {
        scrollContainer.removeChild(textboxContainer);
    };

    textboxContainer.appendChild(textBox);
    textboxContainer.appendChild(deleteButton);
    scrollContainer.insertBefore(textboxContainer, target);
}

document.addEventListener('DOMContentLoaded', function () {
    var checkbox = document.querySelector('input[type="checkbox"]');
    var loginForm = document.getElementById("loginForm");
    var regForm = document.getElementById("regForm");
    var logout = document.getElementById("lo");
    var welcomeMessage = document.getElementById("welcomeMessage");

    chrome.storage.local.get(['username'], function(result) {
        if (result.username !== undefined){
            loginForm.style.display = "none";
            usernameInput = result.username;
            welcomeMessage.innerHTML = "Welcome, " + result.username;
            welcomeMessage.style.display = "block";
            logout.style.display = "block";
        }
    });
    chrome.storage.local.get('enabled', function (result) {
        if (result.enabled != null) {
            checkbox.checked = result.enabled;
        }
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {toggle: checkbox.checked}, function (response) {
            });
        });
    });

    checkbox.addEventListener('click', async function () {
        clearError();
        var tempUsername = "";
        chrome.storage.local.get(['username'], function(result) {
            console.log(result);
            tempUsername = result.username;
            if ((tempUsername === "" || tempUsername === undefined) && checkbox.checked==true){
                var target = document.getElementsByClassName("sliderWrapper")[0]
                showError(2, target, "Please login/register before turn on the switch");
                checkbox.checked = false;
            }
            else {
                console.log(checkbox.checked);
                chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
                    chrome.tabs.sendMessage(tabs[0].id, {toggle: checkbox.checked}, function (response) {
                    });
                });
                chrome.storage.local.set({ 'enabled': checkbox.checked }, function () {
                    console.log("confirmed");
                });
            }
        });
    });

    // section for handling logout
    logout.addEventListener('click', function(){
        chrome.storage.local.remove('username', function() {
            console.log('Item has been removed from local storage');
        });
        chrome.runtime.sendMessage({message: "logout"});
        regForm.style.display = "none";
        welcomeMessage.style.display = "none";
        logout.style.display = "none";
        loginForm.style.display = "block";
    });


    // section for handling login
    // 100: Wrong username/password
    // 200: User already exist
    // 300: pass
    // 400: server error
    var login = document.querySelector('button[type="submit"][id="log"]');
    var username = document.getElementById("username");
    var password = document.getElementById("password");
    var gr = document.getElementById("gr");

    username.addEventListener('click', clearError);
    password.addEventListener('click', clearError);

    login.addEventListener('click', async function(){
        clearError();
        usernameInput = username.value;
        var passwordInput = password.value;
        if (usernameInput == "" || passwordInput == ""){
            showError(1, login, "Invalid username/password, please try again");
        }
        else {
            var json, status;
            json = await postWriterText(1, {state: "login", username: usernameInput, password: passwordInput});
            status = json.status;
            if (status == 300){
                chrome.storage.local.set({'username': usernameInput}, function() {
                  console.log('Data saved successfully!');
                });
                loginForm.style.display = "none";
                welcomeMessage.innerHTML = "Welcome, " + usernameInput;
                welcomeMessage.style.display = "block";
                logout.style.display = "block";
                chrome.runtime.sendMessage({message: "username", username: usernameInput});
            }
            else if (status == 100){
                showError(1, login, "Incorrect username/password, please try again");
            }
            else if (status == 400){
                showError(1, login, "Sever error encountered, please try again");
            }
        }
    });
    gr.addEventListener('click', function(){
        clearError();
        document.documentElement.style.maxHeight = "460px";
        regForm.style.display = "block";
        loginForm.style.display = "none";
    });

    // section for handling registration
    var register = document.querySelector('button[type="submit"][id="reg"]');
    var newUser = document.getElementById("newUser");
    var newPass = document.getElementById("newPass");
    var confirmPass = document.getElementById("confirmPass");
    var gl = document.getElementById("gl");

    newUser.addEventListener('click', clearError);
    newPass.addEventListener('click', clearError);
    confirmPass.addEventListener('click', clearError);

    register.addEventListener('click', async function(){
    	clearError();
        usernameInput = newUser.value;
        var passwordInput = newPass.value;
        var confirmPassInput = confirmPass.value;
        if (usernameInput == "" || passwordInput == "" || confirmPassInput == ""){
            showError(1, register, "Invalid username/password, please try again");
        }
        else if (passwordInput !== confirmPassInput){
            showError(1, register, "Two passwords mismatch, please try again");
        }
        else {
            var json, status
            json = await postWriterText(1, {state: "register", username: usernameInput, password: passwordInput});
            status = json.status;
            if (status == 300){
                chrome.storage.local.set({'username': usernameInput}, function() {
                  console.log('username saved successfully!');
                });
                regForm.style.display = "none";
                welcomeMessage.innerHTML = "Welcome, " + usernameInput;
                welcomeMessage.style.display = "block";
                logout.style.display = "block";
                chrome.runtime.sendMessage({message: "username", username: usernameInput});
            }
            else if (status == 200){
                showError(1, register, "User already exist, choose another name or login");
            }
            else if(status == 400){
                showError(1, register, "Sever error encountered, please try later");
            }
        }
    });
    gl.addEventListener('click', function(){
        clearError();
        document.documentElement.style.maxHeight = "410px";
        regForm.style.display = "none";
        loginForm.style.display = "block";
    });

    //section to handling project IDs tracking
    // 300: pass
    // 400: server error
    // 500: network error
    var manageIDs = document.getElementById("manageIDs");
    var back = document.getElementById("back");
    back.addEventListener('click', function(){
        clearError();
        document.getElementById("manage").style.display="none";
        document.getElementById("control").style.display="block";
    });
    const scrollContainer = document.getElementsByClassName('scroll-container')[0];
    scrollContainer.addEventListener("click", clearError);

    manageIDs.addEventListener('click', function(){
        clearError();
        var tempUsername = ""
        chrome.storage.local.get(['username'], async function(result) {
            tempUsername = result.username;
            if (tempUsername === "" || tempUsername === undefined){
                showError(2, manageIDs, "Please login/register before manage your IDs");
            }
            else {
                manageIDs.innerText = "";
                manageIDs.style.padding = "7px";
                manageIDs.innerHTML = `<i class="fa fa-spinner fa-spin" aria-hidden="true" style="font-size: 22px;"/i>`;
                manageIDs.disabled = true;
                var json, status;
                if (projectIDs?.length === 0 || projectIDs?.length === undefined){
                    json = await postWriterText(2, {task: "getIDs", username: usernameInput});
                    status = json.status;
                }
                if (status === 300){
                    projectIDs = json.project_IDs;
                    document.getElementById("textAtTop").value = projectIDs[0];
                    for (let i = 1; i < projectIDs.length; i++) {
                        addTextBox(projectIDs[i]);
                    }
                    document.getElementById("control").style.display="none";
                    document.getElementById("manage").style.display="grid";
                }
                else if (status === 400){
                    showError(2, manageIDs, "Sever error encountered, please try again later");
                }
                else if (status === 500){
                    showError(2, manageIDs, "Network error, please check internet connection");
                }
                else{
                    document.getElementById("textAtTop").value = projectIDs[0];
                    for (let i = 1; i < projectIDs.length; i++) {
                        addTextBox(projectIDs[i]);
                    }
                    document.getElementById("control").style.display="none";
                    document.getElementById("manage").style.display="grid";
                }
                manageIDs.innerText = "Manage your project IDs";
                manageIDs.style.padding = "10px";
                manageIDs.removeAttribute("disabled");
           }
        });
    });

    const add = document.getElementById("add");
    add.addEventListener("click", function(){addTextBox("");});
    const del = document.getElementById("deleteAtTop");
    del.addEventListener("click", function(event){
        event.target.previousElementSibling.value = "";
    });

    const save = document.getElementById("save");
    save.addEventListener("click", async function(){
        clearError();
        buttons_and_inputs= document.getElementById("manage").querySelectorAll('*');
        buttons_and_inputs.forEach(function (element) {
            element.disabled = true;
        });
        document.getElementById("manage").style.filter = "blur(3Px)";
        document.getElementById("spinner").style.display = "block";
        temp_projectIDs = []
        textboxContainers = document.getElementsByClassName("textbox-container");
        for (var i = 0; i<textboxContainers.length; i++){
            if (textboxContainers[i].children[0].value !== ""){
                temp_projectIDs.push(textboxContainers[i].children[0].value);
            }
        }
        console.log(temp_projectIDs);
        var json = await postWriterText(2, {task: "setIDs",username: usernameInput, project_IDs: temp_projectIDs});
        var status = json.status;
        if (status === 300){
            projectIDs = temp_projectIDs;
            chrome.storage.local.set({"projectIDs": projectIDs}, function() {
                  console.log('project IDs saved successfully!');
            });
            buttons_and_inputs.forEach(function (element) {
                element.removeAttribute('disabled');
            });
            document.getElementById("manage").style.filter = "";
            document.getElementById("spinner").style.display = "none";
        }
        else if (status === 400){
            save.parentElement.previousElementSibling.style.margin = "20px 0px 0px";
            showError(1, save.parentElement, "Sever error encountered, please try again later");
        }
        else if (status === 500){
            showError(1, save.parentElement, "Network error, please check internet connection");
        }
        buttons_and_inputs.forEach(function (element) {
            element.removeAttribute("disabled");
        });
        document.getElementById("manage").style.filter = "";
        document.getElementById("spinner").style.display = "none";
    });
});

async function postWriterText(task, activity) {
    try {
        if (task === 1){
            const response = await fetch(serverURL + "/users", {
                // mode: 'no-cors',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                method: 'POST',
                body: JSON.stringify(activity),
            })
            const message = await response.json();
            console.log(message);
            return message
        }
        else if (task === 2){
            const response = await fetch(serverURL + "/ids", {
                // mode: 'no-cors',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                method: 'POST',
                body: JSON.stringify(activity),
            })
            const message = await response.json();
            console.log(message);
            return message
        }
    }
    catch (err){
        console.log('failed to fetch');
        return {status: 500};
    }
}
